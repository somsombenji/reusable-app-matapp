from django.apps import AppConfig


class MatappConfig(AppConfig):
    name = 'matapp'
