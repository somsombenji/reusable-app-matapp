from django.contrib import admin
from .models import Matzip

admin.site.register(Matzip)
